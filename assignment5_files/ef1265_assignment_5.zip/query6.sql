select s.name stop_f from stations s where s.lines LIKE '%F%';
