select count(*) from stations;
