select name from stations s where s.line='Broadway';
